const Client = require("./src/kahoot.js");

module.exports = Client;
